# Deice Simulator

## To run locally:

1. Unzip the folder.
2. Run `npm install`
3. Run `npm run dev`
4. Open http://localhost:3000 in your browser.

## To deploy:

1. Push this to a GitHub repo
2. Import to Vercel
3. Use default settings, output directory is `dist`