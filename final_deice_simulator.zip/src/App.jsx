import React from 'react';

function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Deice Communication Simulator</h1>
      <p>This is a working version of your simulator app.</p>
    </div>
  );
}

export default App;